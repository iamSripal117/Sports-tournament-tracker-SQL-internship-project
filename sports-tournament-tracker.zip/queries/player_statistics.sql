SELECT p.player_name, t.team_name,
       SUM(s.runs) AS total_runs,
       SUM(s.wickets) AS total_wickets,
       SUM(s.points) AS total_points
FROM Players p
JOIN Stats s ON p.player_id = s.player_id
JOIN Teams t ON p.team_id = t.team_id
GROUP BY p.player_name, t.team_name
ORDER BY total_points DESC;