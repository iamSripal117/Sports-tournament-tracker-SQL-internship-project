SELECT m.match_id, m.match_date, t1.team_name AS Team1, t2.team_name AS Team2,
       p.player_name, s.runs, s.wickets, s.points
FROM Matches m
JOIN Stats s ON m.match_id = s.match_id
JOIN Players p ON s.player_id = p.player_id
JOIN Teams t1 ON m.team1_id = t1.team_id
JOIN Teams t2 ON m.team2_id = t2.team_id
ORDER BY m.match_id, s.points DESC;