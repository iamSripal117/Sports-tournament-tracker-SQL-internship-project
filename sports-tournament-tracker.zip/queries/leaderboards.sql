SELECT t.team_name, SUM(s.points) AS team_points
FROM Teams t
JOIN Players p ON t.team_id = p.team_id
JOIN Stats s ON p.player_id = s.player_id
GROUP BY t.team_name
ORDER BY team_points DESC;