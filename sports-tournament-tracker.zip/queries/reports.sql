WITH PlayerPerformance AS (
  SELECT p.player_name, SUM(s.points) AS total_points
  FROM Players p
  JOIN Stats s ON p.player_id = s.player_id
  GROUP BY p.player_name
)
SELECT * FROM PlayerPerformance
ORDER BY total_points DESC
LIMIT 3;