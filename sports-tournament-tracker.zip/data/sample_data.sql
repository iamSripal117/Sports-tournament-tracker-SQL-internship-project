INSERT INTO Teams (team_name, city) VALUES
('Warriors', 'Mumbai'),
('Titans', 'Delhi'),
('Strikers', 'Bangalore'),
('Challengers', 'Chennai');

INSERT INTO Players (player_name, team_id, role) VALUES
('Rohit Sharma', 1, 'Batsman'),
('Hardik Pandya', 1, 'All-Rounder'),
('Virat Kohli', 3, 'Batsman'),
('MS Dhoni', 4, 'Wicket-Keeper'),
('Shubman Gill', 2, 'Batsman'),
('Mohammed Shami', 2, 'Bowler');

INSERT INTO Matches (match_date, team1_id, team2_id, venue) VALUES
('2025-09-01', 1, 2, 'Mumbai Stadium'),
('2025-09-02', 3, 4, 'Chennai Stadium');

INSERT INTO Stats (match_id, player_id, runs, wickets, points) VALUES
(1, 1, 60, 0, 10),
(1, 2, 30, 2, 12),
(1, 5, 45, 0, 8),
(1, 6, 10, 3, 15),
(2, 3, 80, 0, 15),
(2, 4, 40, 0, 6);